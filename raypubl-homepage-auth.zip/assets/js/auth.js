function openSignup(){
  document.getElementById('signup-section').classList.remove('hidden');
  document.getElementById('login-section').classList.add('hidden');
}
function openLogin(){
  document.getElementById('login-section').classList.remove('hidden');
  document.getElementById('signup-section').classList.add('hidden');
}
