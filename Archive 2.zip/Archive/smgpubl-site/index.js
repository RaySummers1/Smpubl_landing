You’re building with Next.js, so the “index page” lives at pages/index.js, not index.html. I’ll give you:

1. A Next.js homepage (pages/index.js) wired to your components and brand
2. A plain index.html version in case you also want a static mock


---

✅ `pages/index.js` (SMGPUBL℠ Neon/Hybrid Landing)

This assumes you’ll have the components we planned: Header, Footer, HeroSection, BeatCard, MembershipCard, Cart.

// pages/index.js
import { useState } from "react";
import Head from "next/head";
import Header from "../components/Header";
import Footer from "../components/Footer";
import HeroSection from "../components/HeroSection";
import BeatCard from "../components/BeatCard";
import MembershipCard from "../components/MembershipCard";
import Cart from "../components/Cart";

const BEATS = [
  {
    id: "trap1",
    title: "Neon Trap Nexus",
    genre: "Trap",
    bpm: 140,
    mood: "Aggressive",
    price: 29,
    src: "/beats/trap1.mp3",
    cover: "/assets/beat-trap1.jpg"
  },
  {
    id: "lofi2",
    title: "Gentilly Night Drift",
    genre: "Lofi",
    bpm: 82,
    mood: "Chill",
    price: 24,
    src: "/beats/lofi2.mp3",
    cover: "/assets/beat-lofi2.jpg"
  },
  {
    id: "pop3",
    title: "Metairie Skyline Pop",
    genre: "Pop",
    bpm: 120,
    mood: "Uplifting",
    price: 34,
    src: "/beats/pop3.mp3",
    cover: "/assets/beat-pop3.jpg"
  }
];

const MEMBERSHIPS = [
  {
    id: "starter",
    name: "Creator Starter",
    priceMonthly: 19,
    description: "Non-exclusive licenses, 3 downloads/month, email support.",
    highlights: [
      "3 beat licenses/month",
      "MP3 + basic WAV",
      "Email support",
      "Promo-ready tagging"
    ]
  },
  {
    id: "pro",
    name: "Publishing Pro",
    priceMonthly: 49,
    description: "Expanded usage rights, priority support, discount on custom work.",
    highlights: [
      "10 beat licenses/month",
      "WAV stems on select beats",
      "Priority support",
      "Discounted custom production"
    ],
    featured: true
  },
  {
    id: "elite",
    name: "Nexus Elite",
    priceMonthly: 99,
    description: "For serious artists & brands scaling catalogs.",
    highlights: [
      "Unlimited streaming licenses",
      "High-priority requests",
      "Quarterly strategy call",
      "White-label delivery options"
    ]
  }
];

export default function HomePage() {
  const [cartItems, setCartItems] = useState([]);
  const [selectedMembership, setSelectedMembership] = useState(null);

  const handleAddBeatToCart = (beat) => {
    setCartItems((prev) => {
      const exists = prev.find((item) => item.id === beat.id);
      if (exists) {
        return prev.map((item) =>
          item.id === beat.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prev, { ...beat, quantity: 1, type: "beat" }];
    });
  };

  const handleSelectMembership = (membership) => {
    setSelectedMembership(membership);
    setCartItems((prev) => {
      const filtered = prev.filter((item) => item.type !== "membership");
      return [
        ...filtered,
        {
          id: membership.id,
          name: membership.name,
          price: membership.priceMonthly,
          quantity: 1,
          type: "membership"
        }
      ];
    });
  };

  const handleUpdateCartItem = (id, quantity) => {
    setCartItems((prev) =>
      prev
        .map((item) =>
          item.id === id ? { ...item, quantity: Math.max(quantity, 1) } : item
        )
        .filter((item) => item.quantity > 0)
    );
  };

  const handleRemoveCartItem = (id) => {
    setCartItems((prev) => prev.filter((item) => item.id !== id));
  };

  const handleCheckout = () => {
    // Client-side redirect to checkout page with query or use API to create Stripe session
    window.location.href = "/checkout";
  };

  return (
    <>
      <Head>
        <title>SMGPUBL℠ Nexus | Beats, Licensing, Memberships</title>
        <meta
          name="description"
          content="SMGPUBL℠ Nexus — neon-branded publishing hub for beats, memberships, and digital licensing."
        />
      </Head>

      <div className="page-root">
        <Header />

        <main className="main-content">
          <HeroSection />

          <section className="section section-beats" id="beats">
            <div className="section-header">
              <h2>Featured Beat Nexus</h2>
              <p>Curated instrumentals ready for sync, artists, and digital campaigns.</p>
            </div>
            <div className="beat-grid">
              {BEATS.map((beat) => (
                <BeatCard
                  key={beat.id}
                  beat={beat}
                  onAddToCart={() => handleAddBeatToCart(beat)}
                />
              ))}
            </div>
          </section>

          <section className="section section-memberships" id="memberships">
            <div className="section-header">
              <h2>Membership tiers</h2>
              <p>Lock in predictable access to your sound pipeline with SMGPUBL℠ memberships.</p>
            </div>
            <div className="membership-grid">
              {MEMBERSHIPS.map((tier) => (
                <MembershipCard
                  key={tier.id}
                  membership={tier}
                  isSelected={selectedMembership?.id === tier.id}
                  onSelect={() => handleSelectMembership(tier)}
                />
              ))}
            </div>
          </section>

          <section className="section section-cart" id="cart">
            <div className="section-header">
              <h2>Your cart</h2>
              <p>Review your selections before heading into the Nexus checkout.</p>
            </div>
            <Cart
              items={cartItems}
              onUpdateItem={handleUpdateCartItem}
              onRemoveItem={handleRemoveCartItem}
              onCheckout={handleCheckout}
            />
          </section>
        </main>

        <Footer />
      </div>
    </>
  );
}


This will plug into the components we’ll define in the components + styles sections and gives you a real, interactive landing page with beats, memberships, and cart behavior already wired.

---

🧾 Optional: Static `index.html` Mock (if you need a pure HTML version)

If you also want a simple static entry point (for a quick preview or non-Next deployment), here’s an index.html that visually echoes the same structure. This is not used by Next.js, but you can keep it at the repo root or in public/preview/index.html:

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <title>SMGPUBL℠ Nexus | Beats & Licensing</title>
    <meta
      name="description"
      content="SMGPUBL℠ Nexus — neon-branded publishing hub for beats, memberships, and digital licensing."
    />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <style>
      body {
        margin: 0;
        font-family: system-ui, -apple-system, BlinkMacSystemFont, "SF Pro Text",
          sans-serif;
        background: radial-gradient(circle at top, #0ff 0, #050510 55%, #000 100%);
        color: #f5f5f5;
      }
      .page-root {
        min-height: 100vh;
        display: flex;
        flex-direction: column;
      }
      header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 1.25rem 2rem;
        border-bottom: 1px solid rgba(0, 255, 255, 0.2);
        backdrop-filter: blur(12px);
        background: linear-gradient(
          to right,
          rgba(5, 5, 20, 0.95),
          rgba(10, 10, 40, 0.85)
        );
      }
      header .logo {
        font-weight: 700;
        letter-spacing: 0.12em;
        text-transform: uppercase;
        font-size: 0.9rem;
        color: #0ff;
      }
      header nav a {
        margin-left: 1.25rem;
        color: #e5e5ff;
        text-decoration: none;
        font-size: 0.9rem;
      }
      header nav a:hover {
        color: #0ff;
      }
      .hero {
        padding: 3.5rem 2rem 2rem;
        text-align: left;
        max-width: 1100px;
        margin: 0 auto;
      }
      .hero-kicker {
        font-size: 0.8rem;
        letter-spacing: 0.2em;
        text-transform: uppercase;
        color: #7ffcff;
        margin-bottom: 0.5rem;
      }
      .hero h1 {
        font-size: 2.8rem;
        margin: 0 0 0.75rem;
      }
      .hero h1 span {
        color: #0ff;
      }
      .hero p {
        max-width: 540px;
        color: #cfd4ff;
        font-size: 0.98rem;
        line-height: 1.6;
      }
      .hero-actions {
        margin-top: 1.5rem;
        display: flex;
        gap: 1rem;
        flex-wrap: wrap;
      }
      .btn-primary {
        background: linear-gradient(120deg, #0ff, #7b5cff);
        border: none;
        color: #050510;
        padding: 0.7rem 1.4rem;
        border-radius: 999px;
        font-weight: 600;
        font-size: 0.9rem;
        cursor: pointer;
      }
      .btn-outline {
        background: transparent;
        border-radius: 999px;
        border: 1px solid rgba(127, 252, 255, 0.6);
        color: #e5e5ff;
        padding: 0.7rem 1.4rem;
        font-size: 0.9rem;
        cursor: pointer;
      }
      .section {
        padding: 2rem 2rem 2.5rem;
        max-width: 1100px;
        margin: 0 auto;
      }
      .section-header h2 {
        margin: 0 0 0.25rem;
        font-size: 1.4rem;
      }
      .section-header p {
        margin: 0;
        color: #aab0ff;
        font-size: 0.9rem;
      }
      .beat-grid,
      .membership-grid {
        margin-top: 1.5rem;
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
        gap: 1.2rem;
      }
      .card {
        border-radius: 1rem;
        background: rgba(10, 10, 30, 0.95);
        border: 1px solid rgba(127, 252, 255, 0.16);
        padding: 1rem;
      }
      .card-title {
        font-weight: 600;
        margin-bottom: 0.35rem;
      }
      .card-meta {
        font-size: 0.8rem;
        color: #9aa0ff;
        margin-bottom: 0.35rem;
      }
      .card-price {
        font-size: 0.95rem;
        color: #0ff;
        margin-bottom: 0.6rem;
      }
      footer {
        margin-top: auto;
        padding: 1.5rem 2rem;
        font-size: 0.8rem;
        color: #8f90b2;
        border-top: 1px solid rgba(0, 255, 255, 0.15);
        background: radial-gradient(
          circle at bottom,
          rgba(0, 255, 255, 0.08),
          rgba(0, 0, 0, 0.9)
        );
      }
    </style>
  </head>
  <body>
    <div class="page-root">
      <header>
        <div class="logo">SMGPUBL℠ NEXUS</div>
        <nav>
          <a href="#beats">Beats</a>
          <a href="#memberships">Memberships</a>
          <a href="#cart">Cart</a>
        </nav>
      </header>

      <main>
        <section class="hero">
          <div class="hero-kicker">Digital publishing • Licensing • Audio</div>
          <h1>
            A neon <span>Nexus</span> for your catalog.
          </h1>
          <p>
            SMGPUBL℠ bridges hospitality discipline, heavy-equipment precision, and digital publishing into a single,
            controllable licensing hub.
          </p>
          <div class="hero-actions">
            <button class="btn-primary">Browse featured beats</button>
            <button class="btn-outline">Explore memberships</button>
          </div>
        </section>

        <section class="section" id="beats">
          <div class="section-header">
            <h2>Featured Beat Nexus</h2>
            <p>Curated instrumentals ready for sync, artists, and digital campaigns.</p>
          </div>
          <div class="beat-grid">
            <div class="card">
              <div class="card-title">Neon Trap Nexus</div>
              <div class="card-meta">Trap • 140 BPM • Aggressive</div>
              <div class="card-price">$29 / license</div>
            </div>
            <div class="card">
              <div class="card-title">Gentilly Night Drift</div>
              <div class="card-meta">Lofi • 82 BPM • Chill</div>
              <div class="card-price">$24 / license</div>
            </div>
            <div class="card">
              <div class="card-title">Metairie Skyline Pop</div>
              <div class="card-meta">Pop • 120 BPM • Uplifting</div>
              <div class="card-price">$34 / license</div>
            </div>
          </div>
        </section>

        <section class="section" id="memberships">
          <div class="section-header">
            <h2>Membership tiers</h2>
            <p>Lock in predictable access to your sound pipeline with SMGPUBL℠ memberships.</p>
          </div>
          <div class="membership-grid">
            <div class="card">
              <div class="card-title">Creator Starter</div>
              <div class="card-price">$19 / month</div>
              <div class="card-meta">3 licenses • MP3 + basic WAV</div>
            </div>
            <div class="card">
              <div class="card-title">Publishing Pro</div>
              <div class="card-price">$49 / month</div>
              <div class="card-meta">10 licenses • WAV stems • priority support</div>
            </div>
            <div class="card">
              <div class="card-title">Nexus Elite</div>
              <div class="card-price">$99 / month</div>
              <div class="card-meta">Unlimited streaming licenses • strategy support</div>
            </div>
          </div>
        </section>

        <section class="section" id="cart">
          <div class="section-header">
            <h2>Your cart</h2>
            <p>Cart functionality is powered dynamically inside the Next.js app.</p>
          </div>
        </section>
      </main>

      <footer>
        <div>© SMGPUBL℠ Nexus — digital publishing and licensing hub.</div>
      </footer>
    </div>
  </body>
</html>


---

If you want next, I can wire your Header, HeroSection, BeatCard, etc., so pages/index.js plugs directly into the rest of the bundle we started.