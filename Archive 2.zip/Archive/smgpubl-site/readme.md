# SMGPUBL Suite

Full-stack project: React frontend, Node/Express backend, PostgreSQL schema.

## Deploy overview
- Frontend: Netlify or Vercel
- Backend: Render or Railway
- DB: Supabase or Neon

## Environment
- backend/.env (copy from .env.example)
  - DATABASE_URL=postgres://user:pass@host:5432/smgpubl
  - JWT_SECRET=change_this
  - STRIPE_SECRET_KEY=sk_...
  - STRIPE_WEBHOOK_SECRET=whsec_...
  - PAYPAL_WEBHOOK_ID=...
  - NODE_ENV=production
  - PORT=4000

## Commands
- Backend:
  - npm install
  - npm run dev (local) or npm start
- Frontend:
  - npm install
  - npm run start (Vite dev server)

## Zipping
From the parent folder:
zip -r smgpubl-suite.zip smgpubl-suite
