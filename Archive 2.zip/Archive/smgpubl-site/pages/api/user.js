import { PrismaClient } from "@prisma/client";
const prisma = new PrismaClient();

export default async function handler(req, res) {
  try {
    if (req.method === "GET") {
      // Read all users
      const users = await prisma.user.findMany({ include: { payouts: true } });
      return res.status(200).json(users);
    }

    if (req.method === "POST") {
      // Create new user
      const { name, role, balance } = req.body;
      const user = await prisma.user.create({
        data: { name, role, balance: parseFloat(balance) },
      });
      return res.status(201).json(user);
    }

    if (req.method === "DELETE") {
      // Delete user by ID
      const { id } = req.query;
      await prisma.user.delete({ where: { id: parseInt(id) } });
      return res.status(200).json({ message: "User deleted" });
    }

    if (req.method === "PUT") {
      // Update user
      const { id, name, role, balance } = req.body;
      const updated = await prisma.user.update({
        where: { id: parseInt(id) },
        data: { name, role, balance: parseFloat(balance) },
      });
      return res.status(200).json(updated);
    }

    return res.status(405).json({ error: "Method not allowed" });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
}
