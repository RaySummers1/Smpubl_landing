import { PrismaClient } from "@prisma/client";
const prisma = new PrismaClient();

export default async function handler(req, res) {
  try {
    if (req.method === "GET") {
      // Read all payouts
      const payouts = await prisma.payout.findMany({ include: { user: true } });
      return res.status(200).json(payouts);
    }

    if (req.method === "POST") {
      // Create new payout
      const { userId, amount, status } = req.body;
      const payout = await prisma.payout.create({
        data: {
          amount: parseFloat(amount),
          status,
          userId: parseInt(userId),
        },
      });
      return res.status(201).json(payout);
    }

    if (req.method === "DELETE") {
      // Delete payout by ID
      const { id } = req.query;
      await prisma.payout.delete({ where: { id: parseInt(id) } });
      return res.status(200).json({ message: "Payout deleted" });
    }

    if (req.method === "PUT") {
      // Update payout
      const { id, amount, status } = req.body;
      const updated = await prisma.payout.update({
        where: { id: parseInt(id) },
        data: { amount: parseFloat(amount), status },
      });
      return res.status(200).json(updated);
    }

    return res.status(405).json({ error: "Method not allowed" });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
}
