const express = require("express");
const PDFDocument = require("pdfkit");
const router = express.Router();

router.post("/generate", (req, res) => {
  const { name, module } = req.body;
  const doc = new PDFDocument();
  res.setHeader("Content-Type", "application/pdf");
  res.setHeader("Content-Disposition", `attachment; filename=certificate.pdf`);

  doc.fontSize(24).text("Certificate of Completion", { align: "center" });
  doc.moveDown();
  doc.fontSize(16).text(`${name} has completed the module: ${module}`, { align: "center" });
  doc.moveDown();
  doc.text(`Date: ${new Date().toLocaleDateString()}`, { align: "center" });

  doc.end();
  doc.pipe(res);
});

module.exports = router;
