const express = require("express");
const router = express.Router();

// Example quiz data (replace with DB)
const quizzes = {
  basics: require("../data/basics.json"),
  infringement: require("../data/infringement.json"),
};

router.get("/:id", (req, res) => {
  const quiz = quizzes[req.params.id];
  if (!quiz) return res.status(404).json({ error: "Quiz not found" });
  res.json(quiz);
});

router.post("/:id/submit", (req, res) => {
  const { answers } = req.body;
  // Evaluate answers here
  res.json({ score: 4, passed: true });
});

module.exports = router;
