import express from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import pool from "../db.js";

const router = express.Router();

router.post("/signup", async (req, res) => {
  const { email, password, entity, country, plan } = req.body;
  try {
    const hash = await bcrypt.hash(password, 10);
    const result = await pool.query(
      `INSERT INTO users (email, password_hash, entity, country, plan, agreement_accepted)
       VALUES ($1,$2,$3,$4,$5,false) RETURNING user_id`,
      [email, hash, entity, country, plan]
    );
    res.json({ success: true, userId: result.rows[0].user_id });
  } catch (err) {
    res.status(500).json({ success: false, error: "Signup failed" });
  }
});

router.post("/login", async (req, res) => {
  const { email, password } = req.body;
  try {
    const result = await pool.query(
      `SELECT user_id, password_hash FROM users WHERE email=$1`,
      [email]
    );
    if (!result.rows.length) return res.json({ success: false, message: "User not found" });

    const user = result.rows[0];
    const match = await bcrypt.compare(password, user.password_hash);
    if (!match) return res.json({ success: false, message: "Invalid password" });

    const token = jwt.sign({ userId: user.user_id }, process.env.JWT_SECRET, { expiresIn: "2h" });
    res.json({ success: true, userId: user.user_id, token });
  } catch (err) {
    res.status(500).json({ success: false, error: "Login failed" });
  }
});

export default router;
