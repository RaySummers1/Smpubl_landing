import express from "express";
import pool from "../db.js";
import { requireAuth } from "../middleware/auth.js";

const router = express.Router();

router.get("/user/:id/licenses", requireAuth, async (req, res) => {
  const userId = req.params.id;
  if (Number(userId) !== Number(req.userId)) {
    return res.status(403).json({ error: "Forbidden" });
  }

  const result = await pool.query(`
    SELECT b.title, b.genre, l.license_type, l.price, l.purchased_at, p.processor, p.transaction_id
    FROM licenses l
    JOIN beats b ON l.beat_id = b.beat_id
    LEFT JOIN payments p ON l.license_id = p.license_id
    WHERE l.user_id=$1
    ORDER BY l.purchased_at DESC
  `, [userId]);

  res.json(result.rows);
});

export default router;
