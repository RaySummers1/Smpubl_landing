import express from "express";
import pool from "../db.js";
import { requireAuth } from "../middleware/auth.js";

const router = express.Router();

router.post("/agreement/accept", requireAuth, async (req, res) => {
  await pool.query(`UPDATE users SET agreement_accepted=TRUE WHERE user_id=$1`, [req.userId]);
  res.json({ success: true });
});

export default router;
