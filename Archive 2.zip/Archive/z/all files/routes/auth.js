const express = require("express");
const jwt = require("jsonwebtoken");
const router = express.Router();

const SECRET = process.env.JWT_SECRET || "supersecret";

router.post("/login", (req, res) => {
  const { username, password } = req.body;
  if (username === "admin" && password === "changeme") {
    const token = jwt.sign({ role: "admin" }, SECRET, { expiresIn: "1h" });
    res.json({ token });
  } else {
    res.status(401).json({ error: "Invalid credentials" });
  }
});

module.exports = router;
