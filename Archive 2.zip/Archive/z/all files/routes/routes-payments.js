import express from "express";
import pool from "../db.js";
import Stripe from "stripe";

const router = express.Router();
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

router.post("/webhook/stripe", async (req, res) => {
  const event = req.body;
  if (event.type === "checkout.session.completed") {
    const session = event.data.object;
    const txn = session.id;
    const amount = session.amount_total / 100;
    const currency = session.currency.toUpperCase();
    const email = session.customer_email;
    const beatId = session.metadata?.beat_id;
    const licenseType = session.metadata?.license_type;

    try {
      const licenseInsert = await pool.query(
        `INSERT INTO licenses (beat_id, user_id, license_type, price, transaction_id, purchased_at)
         VALUES ($1, (SELECT user_id FROM users WHERE email=$2), $3, $4, $5, NOW())
         RETURNING license_id, user_id`,
        [beatId, email, licenseType, amount, txn]
      );

      const { license_id, user_id } = licenseInsert.rows[0];

      await pool.query(
        `INSERT INTO payments (user_id, license_id, amount, currency, processor, transaction_id, paid_at)
         VALUES ($1, $2, $3, $4, 'Stripe', $5, NOW())`,
        [user_id, license_id, amount, currency, txn]
      );
    } catch (err) {
      console.error("Stripe webhook error:", err);
    }
  }
  res.sendStatus(200);
});

export default router;
