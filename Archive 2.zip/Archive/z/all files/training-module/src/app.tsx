// App.tsx
import Header from "./components/Header";
import Hero from "./components/Hero";
import Section from "./components/Section";
import Accordion from "./components/Accordion";
import BlogSection from "./components/BlogSection";
import Footer from "./components/Footer";

export default function App() {
  return (
    <>
      <Header />
      <main>
        <Hero />
        <Section id="basics" title="What copyright protects">
          {/* Cards for Composition + Recording */}
        </Section>
        <Section id="duration" title="Duration of protection">
          {/* Cards for duration */}
        </Section>
        <Accordion id="infringement" title="What counts as infringement" />
        <Section id="consequences" title="Legal consequences">
          {/* Cards for civil + criminal */}
        </Section>
        <Section id="compliance" title="How to stay compliant">
          {/* Cards for registration + licensing */}
        </Section>
        <BlogSection />
      </main>
      <Footer />
    </>
  );
}
