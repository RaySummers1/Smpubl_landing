export const BlogSection: React.FC = () => (
  <section id="blog">
    <h3>Blogging Section</h3>
    <ul>
      <li>The Basics of Music Copyright Every Artist Should Know</li>
      <li>Top 5 Ways Musicians Accidentally Infringe Copyright</li>
      <li>How to Legally Use Music in Your Projects</li>
      <li>The Real Costs of Copyright Infringement</li>
      <li>Protecting Your Music: A Guide for Independent Artists</li>
    </ul>
  </section>
);
