export const Hero: React.FC = () => (
  <section className="hero">
    <h2>Understand your rights. Use music legally. Protect your work.</h2>
    <p>Copyright automatically protects original compositions and recordings once fixed in a tangible form.</p>
  </section>
);
