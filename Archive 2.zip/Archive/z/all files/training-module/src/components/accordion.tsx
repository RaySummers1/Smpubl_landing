import React, { useState } from "react";

interface Item {
  id: string;
  title: string;
  content: string;
}

interface AccordionProps {
  id: string;
  title: string;
  items: Item[];
}

export const Accordion: React.FC<AccordionProps> = ({ id, title, items }) => {
  const [open, setOpen] = useState<string | null>(null);

  return (
    <section id={id}>
      <h3>{title}</h3>
      <div className="accordion">
        {items.map((item) => (
          <div key={item.id} className="acc-item">
            <button
              className="acc-btn"
              onClick={() => setOpen(open === item.id ? null : item.id)}
            >
              {item.title}
            </button>
            {open === item.id && <div className="acc-panel">{item.content}</div>}
          </div>
        ))}
      </div>
    </section>
  );
};
