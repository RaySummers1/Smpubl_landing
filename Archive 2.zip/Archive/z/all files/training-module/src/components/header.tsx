

import React from "react";

interface HeaderProps {
  onToggleTheme: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onToggleTheme }) => (
  <header className="site">
    <div className="brand">
      <div className="brand-logo" aria-hidden="true"></div>
      <div>
        <h1>Music Copyright & Infringement Laws</h1>
        <div className="subtitle">
          A free, learner-friendly guide for creators and educators
        </div>
      </div>
    </div>
    <div className="controls">
      <button className="btn" onClick={onToggleTheme}>Toggle Theme</button>
      <a className="btn btn-primary" href="#blog">Blogging Section</a>
    </div>
  </header>
);
