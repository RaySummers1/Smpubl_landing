# Training Flow

## 1. Orientation
- Intro hero: purpose, scope, and outcomes
- Quick overview: composition vs. sound recording

## 2. Core Content
- Basics (what copyright protects)
- Duration (terms + public domain basics)
- Infringement (common risks)
- Legal consequences (civil + criminal)
- Compliance (registration, licensing, documentation)

## 3. Quizzes
- Learners complete each section quiz (see /public/quizzes/*.md)
- Passing threshold: customizable in LMS/app layer

## 4. Certificate
- On pass-all, render certificate-template.html with learner name/date
- Export: HTML → PDF via a backend service or client PDF lib

## 5. Extensions
- Blog/learning: case studies, FAQs, resource links
- Automation: CI deploys, analytics, progress tracking
