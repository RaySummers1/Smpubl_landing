// Node.js script to build and upload your app to IONOS via FTP/SFTP
// Requires: npm install basic-ftp

const ftp = require("basic-ftp");
const { execSync } = require("child_process");
const path = require("path");
const fs = require("fs");

async function deploy() {
  try {
    // 1. Build the app
    console.log("Building app...");
    execSync("npm run build", { stdio: "inherit" });

    // 2. Connect to IONOS FTP
    const client = new ftp.Client();
    client.ftp.verbose = true;

    await client.access({
      host: "your-ionos-host",   // e.g. access.ionos.com
      user: "your-ftp-username",
      password: "your-ftp-password",
      secure: true               // use SFTP if available
    });

    // 3. Upload build folder to /htdocs
    const buildDir = path.join(__dirname, "dist"); // or "build" if CRA
    console.log("Uploading files from:", buildDir);

    await client.ensureDir("/htdocs");
    await client.clearWorkingDir(); // optional: clears old files
    await client.uploadFromDir(buildDir);

    client.close();
    console.log("✅ Deployment complete!");
  } catch (err) {
    console.error("Deployment failed:", err);
  }
}

deploy();
