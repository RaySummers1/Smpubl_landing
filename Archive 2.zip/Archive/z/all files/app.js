import React, { useState } from "react";
import Dashboard from "./Dashboard.jsx";

export default function App() {
  const [userId, setUserId] = useState(null);
  const [token, setToken] = useState(null);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  async function handleLogin(e) {
    e.preventDefault();
    try {
      const res = await fetch(`${import.meta.env.VITE_API_URL}/api/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password })
      });
      const data = await res.json();
      if (data.success) {
        setUserId(data.userId);
        setToken(data.token);
      } else {
        alert(data.message || "Login failed");
      }
    } catch (err) {
      console.error(err);
    }
  }

  return (
    <>
      <header><h1>SMGPUBL℠ Membership & Licensing</h1></header>
      {!userId ? (
        <section className="login">
          <h2>Member Login</h2>
          <form onSubmit={handleLogin}>
            <input type="email" placeholder="Email" value={email}
                   onChange={(e) => setEmail(e.target.value)} required />
            <input type="password" placeholder="Password" value={password}
                   onChange={(e) => setPassword(e.target.value)} required />
            <button type="submit">Login</button>
          </form>
        </section>
      ) : (
        <Dashboard userId={userId} token={token} />
      )}
    </>
  );
}
