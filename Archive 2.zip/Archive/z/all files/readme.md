# SMGPUBL℠ Admin Dashboard

A Next.js + Prisma + PostgreSQL scaffold for managing users, payouts, and analytics.  
Includes a frontend landing page, backend API, admin dashboard with CRUD, and Chart.js analytics.

---

## 🚀 Features
- **Frontend**: Static landing page (`frontend/public/index.html`)
- **Backend**: Next.js API routes for users and payouts
- **Database**: PostgreSQL with Prisma ORM
- **Admin Dashboard**:
  - User management (add/delete users)
  - Payout management (add payouts)
  - Analytics with Chart.js (balances, payout trends)
  - Summary cards for quick stats
- **Stripe Integration**: Ready for payouts API

---

## 📂 Project Structure
