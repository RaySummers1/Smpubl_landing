import React, { useEffect, useState } from "react";

export default function Dashboard({ userId, token }) {
  const [licenses, setLicenses] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchLicenses() {
      try {
        const res = await fetch(`${import.meta.env.VITE_API_URL}/api/user/${userId}/licenses`, {
          headers: { Authorization: `Bearer ${token}` }
        });
        const data = await res.json();
        setLicenses(data);
      } catch (err) {
        console.error("Error fetching licenses:", err);
      } finally {
        setLoading(false);
      }
    }
    fetchLicenses();
  }, [userId, token]);

  if (loading) return <p>Loading your dashboard...</p>;

  return (
    <section className="dashboard">
      <h2>Member Dashboard</h2>
      <p>Welcome back! Here are your licensed beats:</p>
      <table className="licenses-table">
        <thead>
          <tr>
            <th>Beat Title</th>
            <th>Genre</th>
            <th>License Type</th>
            <th>Price</th>
            <th>Purchased At</th>
            <th>Processor</th>
            <th>Transaction ID</th>
          </tr>
        </thead>
        <tbody>
          {licenses.map((lic, idx) => (
            <tr key={idx}>
              <td>{lic.title}</td>
              <td>{lic.genre}</td>
              <td>{lic.license_type}</td>
              <td>${Number(lic.price).toFixed(2)}</td>
              <td>{new Date(lic.purchased_at).toLocaleString()}</td>
              <td>{lic.processor || "-"}</td>
              <td>{lic.transaction_id || "-"}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </section>
  );
}
