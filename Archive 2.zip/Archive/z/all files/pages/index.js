export default function Home() {
  return (
    <div>
      <h1>Backend API Running</h1>
      <p>Welcome to SMGPUBL℠ backend service.</p>
    </div>
  );
}
