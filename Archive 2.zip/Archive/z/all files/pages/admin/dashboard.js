import { useState } from "react";

export default function Dashboard() {
  const [users] = useState([
    { id: 1, name: "Alice", role: "Creator", balance: "$120.00" },
    { id: 2, name: "Bob", role: "Client", balance: "$75.50" },
    { id: 3, name: "Charlie", role: "Admin", balance: "$0.00" },
  ]);

  const [payouts] = useState([
    { id: 101, user: "Alice", amount: "$50.00", status: "Completed" },
    { id: 102, user: "Bob", amount: "$25.00", status: "Pending" },
  ]);

  return (
    <div style={{ fontFamily: "Arial, sans-serif", padding: "20px" }}>
      <h1>Admin Dashboard</h1>
      <p>Manage payouts, users, and content here.</p>

      {/* User Management */}
      <section style={{ marginTop: "30px" }}>
        <h2>👥 Users</h2>
        <table border="1" cellPadding="10" style={{ width: "100%", marginTop: "10px" }}>
          <thead>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Role</th>
              <th>Balance</th>
            </tr>
          </thead>
          <tbody>
            {users.map((user) => (
              <tr key={user.id}>
                <td>{user.id}</td>
                <td>{user.name}</td>
                <td>{user.role}</td>
                <td>{user.balance}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>

      {/* Payouts */}
      <section style={{ marginTop: "30px" }}>
        <h2>💸 Payouts</h2>
        <table border="1" cellPadding="10" style={{ width: "100%", marginTop: "10px" }}>
          <thead>
            <tr>
              <th>ID</th>
              <th>User</th>
              <th>Amount</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {payouts.map((payout) => (
              <tr key={payout.id}>
                <td>{payout.id}</td>
                <td>{payout.user}</td>
                <td>{payout.amount}</td>
                <td>{payout.status}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>

      {/* Analytics */}
      <section style={{ marginTop: "30px" }}>
        <h2>📊 Analytics</h2>
        <div style={{ display: "flex", gap: "20px", marginTop: "10px" }}>
          <div style={{ flex: 1, background: "#f0f0f0", padding: "20px", textAlign: "center" }}>
            <h3>Total Users</h3>
            <p>{users.length}</p>
          </div>
          <div style={{ flex: 1, background: "#f0f0f0", padding: "20px", textAlign: "center" }}>
            <h3>Total Payouts</h3>
            <p>{payouts.length}</p>
          </div>
        </div>
      </section>
    </div>
  );
}
